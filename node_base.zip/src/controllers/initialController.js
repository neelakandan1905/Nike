const Library = require('../../database/models/Libary')
const sanitize = require('mongo-sanitize');
const initalService = require('../service/initialService');

const initalController = {
    
    consoleMethod: async (req, res) => {
        return res.send(`consoleMethod Working`);
    },

    tryGet: async (req, res) => {
        console.log(req, res);
        try {
            const libraryData = await Library.find();
                // .collation({
                //     locale: process.env.DEFAULT_LANGUAGE || 'en',
                //     numericOrdering: true,
                // }).lean();
            return res.status(200).json(libraryData);
        } catch(err) {
            return res.status(500).send(err.message);
        }
    },

    tryPost: async (req, res) => {
        try {
            req.body = sanitize(req.body)
            res.send(req.body)
        } catch (err) {

        }
    },

    //using Service
    tryPostService: async (req, res) => {
        try {
            req.body = sanitize(req.body)
            const data = await initalService.postService(req.body);
            res.send(data)
        } catch (err) {

        }
    },


    tryPostViaContoller: async (req, res) => {
        try {
            req.body = sanitize(req.body);
            // if(req.body.displayName) {
            const libCreate = await Library.create(req.body);
            return res.status(201).send(libCreate);
            // } 
            // else {
            //     return res.status(500).send('displayName is mandatory');
            // }
        } catch (error) {
            console.log(error.code);
            // Check if the error is a Mongoose validation error and handle it accordingly
            if (error.name === 'ValidationError') {
                // Send back a detailed error message in case of validation failure
                return res.status(400).json({
                    message: 'Validation failed',
                    errors: error.errors.displayName.message,
                    code: error.code
                });
            }

            // Handle other types of errors (if any)
            return res.status(500).json({
                message: 'An unexpected error occurred',
                error: error.message
            });
            // logger.error("Error in adding Library: " + error.stack);
            // commonUtils.handleError(error, res);
        }
    },

     tryPostViaService: async (req, res) => {
        const[status, response] = await initalService.postLibrary(req.body);
        return res.status(status).send(response);
     }, catch(error) {
         console.log(error);
        //  logger.error("Error in adding Library: " + error.stack);
         // commonUtils.handleError(error, res);
     },

     tryGetById: async (req, res) => {
         console.log(req.params);
         const [status, response] = await initalService.libraryGetById(req.params);
         return res.status(status).send(response);
     }, catch (error) {
        console.log(error);
     }

}

module.exports = initalController;