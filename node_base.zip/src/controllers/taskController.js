const Task = require("../../database/models/task");
const commonUtils = require("../utils/commonUtils");

const taskController = {

    // Create a new task
    postTask: async (req, res) => {
        try { 
            const { title, description } = req.body;
            const newTask = new Task({ title, description });
            const taskCreate = await Task.create(newTask);
            return res.status(201).send(taskCreate);
        } catch(err) {
            commonUtils.handleError(err, res);
        }
    },

    // get all task
    getAllTask: async(req, res) => {
        try {
            const task = await Task.find();
            return res.status(200).send(task);
        } catch(err) {
            commonUtils.handleError(err, res);
        }
    },

    // get task by id
    getTaskById: async (req, res) => {
        try {
            const task = await Task.findById(req.params.id);
            return res.status(200).send(task);
        } catch (err) {
            commonUtils.handleError(err, res);
        }
    },

    //update Task by id
    updateTask: async (req, res) => {
        try {
            const {
                title, 
                description, 
                completed
            } = req.body;
            const task = await Task.findByIdAndUpdate(
                req.params.id,                      // Passing the updating field id
                {title, description, completed},    // Payload
                { new: true }                       // true will teturn the updated document after the update.
            );
            if (!task) {
                return res.status(404).json({ error: 'Task not found' });
            }
            return res.status(200).send(task);
        } catch (err) {
            commonUtils.handleError(err, res);
        }
    },


    // hard delete
    deleteTask: async (req,res) => {
        try {
            const task = await Task.findByIdAndDelete(req.params.id);
            if (!task) {
                return res.status(404).json({ error: 'Task not found' });
            }
            return res.status(200).send(task);
        } catch (err) {
            commonUtils.handleError(err, res);
        }
    },

    // soft delete
    softDelete: async (req, res) => {
        try {
            const deletePayload = { isDeleted: true };
            const task = await Task.findByIdAndUpdate(req.params.id, deletePayload, {
                new: true, // Return the updated document
                runValidators: true, // Ensure new data is validated
            });
            if (!task) {
                return res.status(404).json({ error: 'Task not found' });
            }
            res.status(200).json(task);
        } catch (err) {
            commonUtils.handleError(err, res);
        }
    },

    getTasks: async (req, res) => {
        try {
            const {
                offset = 0,
                limit = 10,
                searchKey="",
                sortBy = "createdOn"
            } = req.query;
            const searchText = searchKey.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
            const regexSearchText = searchText ? new RegExp(searchText, "i") : '';

            let custom = {
                isDeleted: false,
                $or: [
                    { title: { $regex: regexSearchText } },
                    { description: { $regex: regexSearchText } }
                ]
            }
            const [task, count] = await Promise.all([
                await Task.find(custom).sort(sortBy).skip(offset).limit(limit),
                await Task.countDocuments({ isDeleted: false })
            ])
            if (task) {
                const response = {
                    items: task,
                    total: count
                }
                return res.status(200).send(response);
            } else {
                return res.status(200).send([]);
            }
        } catch (err) {
            commonUtils.handleError(err, res);
        }
    }

}

module.exports = taskController;