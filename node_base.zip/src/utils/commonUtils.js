const commonUtils = {

    handleError: function (error, res) {
        if (error.name === 'ValidationError') {
            this.handleValidationError(error, res);
        } else {
            res.status(500).send(error.message);
        }
    },

    handleValidationError: function (error, res) {
        for (let field in error.errors) {
            if (error.errors[field].kind === 'maxlength') {
                let responseMsg = [{ Error: "Validation Failed", "message": `Must be ${error.errors[field].properties.maxlength} or less characters`, "fieldKey": field }];
                return res.status(409).send(responseMsg);
            }
            else {
                let responseMsg = [{ Error: "Validation Failed", "message": error.errors[field].message, "fieldKey": field }];
                return res.status(409).send(responseMsg);
            }
        }
    }

    

}

module.exports = commonUtils;