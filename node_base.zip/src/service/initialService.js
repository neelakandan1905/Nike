const Library = require("../../database/models/Libary");


const initalService = {

    postService: async (req) => {
        return req
    },

    postLibrary: async (req) => {
        try{
            if (req?.displayName) {
                const libraryCheck = await Library.findOne({ displayName : req.displayName});
                console.log(libraryCheck);
                const libCreate = await Library.create(req);
                return [200, libCreate]
            } else {
                return [500, 'displayName is mandatory'];
            }
        } catch(err) {
            console.log(err);
        }
    },

    libraryGetById: async (req) => {
        try {
            if (req) {
                const getSingleLibrary = await Library.findById(req.id);
                if (getSingleLibrary) {
                    return [200, getSingleLibrary];
                } else {
                    return [404, 'No library found with the requested Id.']; // 404 for not found
                }
            } else {
                return [400, 'Invalid request.']; // 400 for bad request
            }
        } catch (err) {
            console.error('Error in libraryGetById:', err); // Log the error for debugging
            return [500, 'Internal Server Error']; // 500 for server error
        }
    }

}

module.exports = initalService;