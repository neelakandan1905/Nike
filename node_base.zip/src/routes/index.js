const express = require('express');
let router = express.Router();

router.get('/', function(req, res, next) {
    console.log('test');
    res.render('index', {app: 'node base'});
});

router.use('/initial', require('./initialRoutes'));
router.use('/task', require('./taskRoutes'));

router.use((err, req, res, next) => {
    if (err) {
        console.log("Error :", err, req.body);
        // logger.error('Error in API: ' + err);
        res.status(500).json({ status: false, error: err });
    }
});

module.exports = router;