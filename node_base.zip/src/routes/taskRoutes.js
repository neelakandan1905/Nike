const express = require('express');
const taskController = require('../controllers/taskController');
const router = express.Router();

router.post('/', taskController.postTask);
router.get('/all', taskController.getAllTask);
router.get('/:id', taskController.getTaskById);
router.put('/:id', taskController.updateTask);
router.delete('/:id', taskController.deleteTask);
router.delete('/sd/:id', taskController.softDelete);
router.get('/', taskController.getTasks);

module.exports = router;