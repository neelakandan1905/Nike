const express = require('express');
const router = express.Router();
const initalController = require('../controllers/initialController')

router.get('/',initalController.consoleMethod);
router.get('/tryGet', initalController.tryGet);
router.post('/tryPost', initalController.tryPost);
router.post('/tryPostUsingService', initalController.tryPostService);
router.post('/tryLibraryPost', initalController.tryPostViaContoller);
router.post('/tryLibraryPostUseService', initalController.tryPostViaService);
router.get('/library/:id', initalController.tryGetById)

module.exports = router;