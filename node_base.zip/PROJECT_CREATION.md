## project creation

- Install Node.js and npm
    1. Install Node.js and npm
    2. Verify the installation by opening a Command Prompt (cmd) and typing:
    -----------------------------------------------------------
        node -v
        npm -v
    -----------------------------------------------------------

- Set Up a New Project
    1. Open a Command Prompt (cmd).
    2. Create a new directory for your project and navigate into it:
    -----------------------------------------------------------
        mkdir my-express-app
        cd my-express-app
    -----------------------------------------------------------

    3. Initialize a new Node.js project:
    -----------------------------------------------------------
        npm init -y
    -----------------------------------------------------------
    This will create a package.json file with default settings.

- Install Express
    1. Install Express using npm:
    -----------------------------------------------------------
        npm install express --save
    -----------------------------------------------------------

- Create a Basic Express Server
    1. Create a new file named app.js in your project directory:
    -- type nul > app.js
    2. Open app.js in a text editor and add the following code:
    -----------------------------------------------------------
        const express = require('express');
        const app = express();
        const port = 3000;

        app.get('/', (req, res) => {
        res.send('Hello World!');
        });

        app.listen(port, () => {
        console.log(`Example app listening at http://localhost:${port}`);
        });
    -----------------------------------------------------------

- Run Your Server
    1. Run Your Server
    2. Open a web browser and go to http://localhost:3000. You should see "Hello World!" displayed.

- Optional, Use Nodemon for Auto-Restart
    1. Install Nodemon globally: (To automatically restart your server when you make changes, you can use Nodemon.)
    -----------------------------------------------------------
    npm install -g nodemon
    -----------------------------------------------------------