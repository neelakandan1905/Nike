const mongoose = require('mongoose');

const dbOptions = {
    // useNewUrlParser: true,
    // useUnifiedTopology: true,
    //reconnectTries:  10, // This option is deprecated and may not be supported in the latest versions of Mongoose.
    //reconnectInterval: 1500,
    connectTimeoutMS: 1000000,
    socketTimeoutMS: 1000000,
    maxPoolSize: 1000,
    maxIdleTimeMS: 60000,
    // keepAlive: true,
};

const establishDb = () => mongoose.connect(process.env.DB_URL, dbOptions).catch(error => {
    // logger.error(error.stack);
    console.log(error);
});

mongoose.set('strictQuery', true)

mongoose.connection.on('connected', () => {
    // logger.info('database connected');
    console.log('database connected');
});
mongoose.connection.on('disconnected', () => {
    console.log('database disconnected');
});
mongoose.connection.on('error', err => {
    console.log('error', err);
});
mongoose.connection.close().then(res => {
    console.log("Mongoose Connections Closed");
}).catch(err => {
    console.log('Error closing Mongo Connection: ' + err);
    // logger.error('Error closing Mongo Connection: ' + err);
});


module.exports = establishDb;