const mongoose = require('mongoose');
const {Schema} = mongoose;
const librarySchema = new Schema({
    displayName: {
        type: String,
        required: [true, 'displayName is required'], // Field is required with a custom error message
        maxlength: 10, // Field is required with a custom error message
        // validate: {            // Custom validator to ensure it's strictly a string
        //     validator: function (value) {
        //         return typeof value === 'string';
        //     },
        //     message: 'Display name must be a string'
        // },
        trim: true, // Removes whitespace around the string
    }
},
{timeStamp: true}
);

librarySchema.index({ displayName: 1});
const Library = mongoose.model('Library', librarySchema);
module.exports = Library;