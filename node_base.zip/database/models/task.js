const mongoose = require('mongoose');
const { Schema } = mongoose;

const taskSchema = new Schema(
    {
        title: {
            type: String,
            required: [true, 'title is required'],
            maxlength: [10, 'title should not exceed length 10']
        },
        description: String,
        completed: {
            type: Boolean,
            default: false
        },
        isDeleted: {
            type: Boolean,
            default: false
        },
        createdOn: {
            type: Date,
            default: Date.now, // Automatically set the createdOn field when the document is created
            immutable: true // Prevents modification of this field after creation
        },
        updatedOn: {
            type: Date,
            default: null, // Initially set to null
        },
    },
    // {
    //     timestamps:
    //     {
    //         createdAt: "createdOn",
    //         updatedAt: "updatedOn"
    //     }
    // }
);

// Pre-save hook to update the updatedOn field only on updates
taskSchema.pre('findOneAndUpdate', function (next) {
    this.set({ updatedOn: new Date() });
    next();
});

taskSchema.index({ title: 1, completed: 1 });
const Task = mongoose.model('Task', taskSchema);
module.exports = Task;