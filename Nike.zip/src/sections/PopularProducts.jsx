const PopularProducts = () => {
  return (
    <div>PopularProducts</div>
  )
}

export default PopularProducts