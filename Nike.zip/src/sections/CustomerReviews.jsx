const customerReviews = () => {
  return (
    <div>customerReviews</div>
  )
}

export default customerReviews